export interface BlogModel{
    sid:number;
    title:string;
    description:string;
}